<?php
defined('BASEPATH') or exit('No direct script access allowed');

include_once 'Admin_controller.php';

class Extra extends Admin_Controller
{
    public function __construct()
    {
        parent::__construct();
        // $this->check_login();
        $this->load->model('story_model');
        $this->load->model('story_description_model');
    }

    public function update_sound()
    {
        $id = get_param_from_request('id');
        $type = get_param_from_request('type');
        

        $storyItem = $this->story_model->get(array("id" => $id));
        if (empty($storyItem)) {
            output_error("Story doesn't exist");
        } else {
            
            if (isset($_FILES['soundFile'])) {
                $sound_url = $this->upload_file("contents/v8".$storyItem['resources_base_url'], "soundFile");
                $this->story_model->update(array('augmented_sound_url'=>$sound_url), array('id'=>$id));
            }
            output_data(1);
        }

    }

    
    
}
