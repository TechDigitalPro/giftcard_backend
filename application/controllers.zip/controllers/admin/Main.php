<?php
defined('BASEPATH') OR exit('No direct script access allowed');

include_once 'Admin_controller.php';

class Main extends Admin_Controller {
    public function __construct(){
        parent::__construct();
    }

    public function login(){
        $email = get_param_from_request('email');
        if($email == '') output_error("email is required");
        $password = get_param_from_request("password");
        if($password == '') output_error("Password is required");
        $condition = array(
            'admin_email'=>$email
        );
        $admin_info = $this->admin_model->get($condition);
        if(empty($admin_info)){
            output_error("Incorrect login info");
        }
        if(md5($password) !== $admin_info['admin_password']) {
            output_error("Incorrect login info");
        }
        $token = $this->_create_token(array("id"=>$admin_info['admin_id'], "password"=>$admin_info['admin_password'], "user_type"=>"admin"));
        $result = array('token'=>$token, 'user_info'=>$admin_info);

        $browserInfo = getBrowser();
        $log_info = array(
            'user_id'=>$admin_info['admin_id'],
            'log_type'=>'login',
            'user_type'=>'admin',
            'ip'=>get_client_ip(),
            'browser_info'=>$browserInfo,
            'timestamp'=>TIMESTAMP
        );
        $this->access_log_model->insert($log_info);

        output_data($result);
    }
    private function _create_token($user_info, $delete_failed=false){

        $token = md5($user_info['id']).md5($user_info['password'] . strval(TIMESTAMP) . strval(rand(0,999999)));
        $condition['user_id'] = $user_info['id'];
        $mb_user_token_info = $this->mb_token_model->get($condition);
        if(!empty($mb_user_token_info)) {
            $update_data = array();
            $update_data['user_id'] = $user_info['id'];
            $update_data['user_type'] = $user_info['user_type'];
            $update_data['token'] = $token;
            $update_data['login_time'] = TIMESTAMP;
            $update_data['api_version'] = $this->api_version;
            $result = $this->mb_token_model->update($update_data, $condition);
        } else {
            $mb_user_token_info = array();
            $mb_user_token_info['user_id'] = $user_info['id'];
            $mb_user_token_info['user_type'] = $user_info['user_type'];
            $mb_user_token_info['token'] = $token;
            $mb_user_token_info['login_time'] = TIMESTAMP;
            $mb_user_token_info['api_version'] = $this->api_version;
            $result = $this->mb_token_model->insert($mb_user_token_info);
        }
        return $token;
    }
}