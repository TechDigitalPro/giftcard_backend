<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'third_party/paypal/paypal.php';
require_once APPPATH . 'third_party/stripe-php/init.php';
include_once 'Mobile_controller.php';

class Main extends Mobile_controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('story_model');
        $this->load->model('story_description_model');
        $this->load->model('addiopizzo_model');
        $this->load->model('configuration_model');
        $this->load->model('francese_model');
        $this->load->model('project_model');
        $this->load->model('story_detail_model');
    }
    public function get_story_list()
    {

        $type = get_param_from_request('type');
        if (empty($type)) {
            output_error("type is required");
        }

        $data_list = $this->story_model->get_all(array('type' => $type, 'status' => 1));
        if (empty($data_list)) {
            output_error("invalid type");
        }
        foreach ($data_list as $key => $item) {
            $data_list[$key]['address'] = json_decode($item['address']);
            $data_list[$key]['id'] = $item['index'];
            $data_list[$key]['bodyguard_team'] = json_decode($item['bodyguard_team']);
            $bList = json_decode($item['bodyguard_team']);
            if (sizeof($bList) > 0) {
                foreach ($bList as $keys => $items) {
                    $bodyguard_info = $this->story_description_model->get(array('key' => $items->bodyguard_description, 'type' => $type));
                    $bodyguard_en = "";
                    $bodyguard_it = "";
                    if (!empty($bodyguard_info)) {
                        $bodyguard_en = $bodyguard_info['des_en'];
                        $bodyguard_it = $bodyguard_info['des_it'];
                    }
                    if ($bodyguard_en == null) {
                        $bodyguard_en = "";
                    }
                    if ($bodyguard_it == null) {
                        $bodyguard_it = "";
                    }
                    $bList[$keys]->bodyguard_description = array(
                        "en" => $bodyguard_en,
                        "it" => $bodyguard_it,
                    );
                }
                $data_list[$key]['bodyguard_team'] = $bList;
            }
            $des_info = $this->story_description_model->get(array('key' => $item['description'], 'type' => $type));
            $des_en = "";
            $des_it = "";
            if (!empty($des_info)) {
                $des_en = $des_info['des_en'];
                $des_it = $des_info['des_it'];
            }
            if ($des_en == null) {
                $des_en = "";
            }
            if ($des_it == null) {
                $des_it = "";
            }
            $data_list[$key]['description'] = array(
                "en" => $des_it,
                "it" => $des_en,
            );
            $bodyguard_title_info = $this->story_description_model->get(array('key' => $item['bodyguard_title'], 'type' => $type));
            $bodyguard_title_en = "";
            $bodyguard_title_it = "";
            if (!empty($bodyguard_title_info)) {
                $bodyguard_title_en = $bodyguard_title_info['des_en'];
                $bodyguard_title_it = $bodyguard_title_info['des_it'];
            }
            if ($bodyguard_title_en == null) {
                $bodyguard_title_en = "";
            }
            if ($bodyguard_title_it == null) {
                $bodyguard_title_it = "";
            }
            $data_list[$key]['bodyguard_title'] = array(
                "en" => $bodyguard_title_en,
                "it" => $bodyguard_title_it,
            );
            $geofenceTitle_info = $this->story_description_model->get(array('key' => $item['geofenceTitle'], 'type' => $type));
            $geofenceTitle_en = "";
            $geofenceTitle_it = "";
            if (!empty($geofenceTitle_info)) {
                $geofenceTitle_en = $geofenceTitle_info['des_en'];
                $geofenceTitle_it = $geofenceTitle_info['des_it'];
            }
            if ($geofenceTitle_en == null) {
                $geofenceTitle_en = "";
            }
            if ($geofenceTitle_it == null) {
                $geofenceTitle_it = "";
            }
            $data_list[$key]['geofenceTitle'] = array(
                "en" => $geofenceTitle_en,
                "it" => $geofenceTitle_it,
            );
            $speakerDescription_info = $this->story_description_model->get(array('key' => $item['speakerDescription'], 'type' => $type));
            $speakerDescription_en = "";
            $speakerDescription_it = "";
            if (!empty($speakerDescription_info)) {
                $speakerDescription_en = $speakerDescription_info['des_en'];
                $speakerDescription_it = $speakerDescription_info['des_it'];
            }
            if ($speakerDescription_en == null) {
                $speakerDescription_en = "";
            }
            if ($speakerDescription_it == null) {
                $speakerDescription_it = "";
            }
            $data_list[$key]['speakerDescription'] = array(
                "en" => $speakerDescription_en,
                "it" => $speakerDescription_it,
            );

            $geofenceAlert_info = $this->story_description_model->get(array('key' => $item['geofenceAlert'], 'type' => $type));
            $geofenceAlert_en = "";
            $geofenceAlert_it = "";
            if (!empty($geofenceAlert_info)) {
                $geofenceAlert_en = $geofenceAlert_info['des_en'];
                $geofenceAlert_it = $geofenceAlert_info['des_it'];
            }
            if ($geofenceAlert_en == null) {
                $geofenceAlert_en = "";
            }
            if ($geofenceAlert_it == null) {
                $geofenceAlert_it = "";
            }
            $data_list[$key]['geofenceAlert'] = array(
                "en" => $geofenceAlert_en,
                "it" => $geofenceAlert_it,
            );

            

            unset($data_list[$key]['type']);
            unset($data_list[$key]['index']);
            unset($data_list[$key]['admin_id']);
            unset($data_list[$key]['status']);
            unset($data_list[$key]['timestamp']);
        }

        $detail_item = $this->story_detail_model->get(array("type" => $type));
        $detail_info = array();
        if (!empty($detail_item)) {

            $detail_description_info = $this->story_description_model->get(array('key' => $detail_item['description'], 'type' => $type . "_detail"));
            $detail_description_en = "";
            $detail_description_it = "";
            if (!empty($detail_description_info)) {
                $detail_description_en = $detail_description_info['des_en'];
                $detail_description_it = $detail_description_info['des_it'];
            }
            if ($detail_description_en == null) {
                $detail_description_en = "";
            }
            if ($detail_description_it == null) {
                $detail_description_it = "";
            }

            $detail_info['description'] = array(
                "en" => $detail_description_en,
                "it" => $detail_description_it,
            );

            $detail_content_info = $this->story_description_model->get(array('key' => $detail_item['bodyguard_title'], 'type' => $type . "_detail"));
            $detail_content_en = "";
            $detail_content_it = "";
            if (!empty($detail_content_info)) {
                $detail_content_en = $detail_content_info['des_en'];
                $detail_content_it = $detail_content_info['des_it'];
            }
            if ($detail_content_en == null) {
                $detail_content_en = "";
            }
            if ($detail_content_it == null) {
                $detail_content_it = "";
            }

            $detail_info['bodyguard_title'] = array(
                "en" => $detail_content_en,
                "it" => $detail_content_it,
            );

            $detail_info['name'] = empty($detail_item['name']) ? "" : $detail_item['name'];
            $detail_info['short_name'] = empty($detail_item['short_name']) ? "" : $detail_item['short_name'];
            $detail_info['profile_icon'] = empty($detail_item['profile_icon']) ? "" : $detail_item['profile_icon'];
            $detail_info['speaker_icon'] = empty($detail_item['speaker_icon']) ? "" : $detail_item['speaker_icon'];
            $detail_info['augmented_sound_url'] = empty($detail_item['augmented_sound_url']) ? "" : $detail_item['augmented_sound_url'];
            $detail_info['resources_base_url'] = $detail_item['resources_base_url'];
        }
        
        output_data(array("list" => $data_list, "detail" => $detail_info));
    }
    public function get_story_detail()
    {
        $type = get_param_from_request('type');
        if (empty($type)) {
            output_error("paramter error");
        }
        $detail_item = $this->story_detail_model->get(array("type" => $type));
        if (empty($detail_item)) {
            output_error("Story doesn't exist");
        }

        $detail_info = array();
        $detail_description_info = $this->story_description_model->get(array('key' => $detail_item['description'], 'type' => $type . "_detail"));
        $detail_description_en = "";
        $detail_description_it = "";
        if (!empty($detail_description_info)) {
            $detail_description_en = $detail_description_info['des_en'];
            $detail_description_it = $detail_description_info['des_it'];
        }
        if ($detail_description_en == null) {
            $detail_description_en = "";
        }
        if ($detail_description_it == null) {
            $detail_description_it = "";
        }

        $detail_info['description'] = array(
            "en" => $detail_description_en,
            "it" => $detail_description_it,
        );

        $detail_content_info = $this->story_description_model->get(array('key' => $detail_item['bodyguard_title'], 'type' => $type . "_detail"));
        $detail_content_en = "";
        $detail_content_it = "";
        if (!empty($detail_content_info)) {
            $detail_content_en = $detail_content_info['des_en'];
            $detail_content_it = $detail_content_info['des_it'];
        }
        if ($detail_content_en == null) {
            $detail_content_en = "";
        }
        if ($detail_content_it == null) {
            $detail_content_it = "";
        }

        $detail_info['bodyguard_title'] = array(
            "en" => $detail_content_en,
            "it" => $detail_content_it,
        );

        $detail_info['name'] = empty($detail_item['name']) ? "" : $detail_item['name'];
        $detail_info['short_name'] = empty($detail_item['short_name']) ? "" : $detail_item['short_name'];
        $detail_info['profile_icon'] = empty($detail_item['profile_icon']) ? "" : $detail_item['profile_icon'];
        $detail_info['speaker_icon'] = empty($detail_item['speaker_icon']) ? "" : $detail_item['speaker_icon'];
        $detail_info['augmented_sound_url'] = empty($detail_item['augmented_sound_url']) ? "" : $detail_item['augmented_sound_url'];
        $detail_info['resources_base_url'] = $detail_item['resources_base_url'];

        output_data($detail_info);
    }
    public function get_francese()
    {
        $data_list = $this->francese_model->get_all(array('status' => 1));
        foreach ($data_list as $key => $item) {
            $data_list[$key]['cube_rotations'] = json_decode($item['cube_rotations']);
            $data_list[$key]['cube_textures'] = json_decode($item['cube_textures']);
            $data_list[$key]['cube_textures_low'] = json_decode($item['cube_textures_low']);
            $data_list[$key]['steps'] = json_decode($item['steps']);
            $data_list[$key]['supported_languages'] = json_decode($item['supported_languages']);
            unset($data_list[$key]['id']);
            unset($data_list[$key]['admin_id']);
            unset($data_list[$key]['status']);
            unset($data_list[$key]['timestamp']);
        }
        output_data($data_list[0]);
    }
    public function get_addiopizzo()
    {
        $data_list = $this->addiopizzo_model->get_all(array('status' => 1));
        foreach ($data_list as $key => $item) {

            $cat_info = $this->story_description_model->get(array('key' => $item['cat'], 'type' => "addiopizzo"));
            $cat_en = "";
            $cat_it = "";
            if (!empty($cat_info)) {
                $cat_en = $cat_info['des_en'];
                $cat_it = $cat_info['des_it'];
            }
            if ($cat_en == null) {
                $cat_en = "";
            }
            if ($cat_it == null) {
                $cat_it = "";
            }
            $data_list[$key]['cat'] = array(
                "en" => $cat_en,
                "it" => $cat_it,
            );

            $subcat_info = $this->story_description_model->get(array('key' => $item['subcat'], 'type' => "addiopizzo"));
            $subcat_en = "";
            $subcat_it = "";
            if (!empty($subcat_info)) {
                $subcat_en = $subcat_info['des_en'];
                $subcat_it = $subcat_info['des_it'];
            }
            if ($subcat_en == null) {
                $subcat_en = "";
            }
            if ($subcat_it == null) {
                $subcat_it = "";
            }
            $data_list[$key]['subcat'] = array(
                "en" => $subcat_en,
                "it" => $subcat_it,
            );
            $data_list[$key]['contacts'] = array(
                "phone" => $item['phone'],
                "web" => $item['web'],
            );
            $data_list[$key]['extra'] = array(
                "cat" => $data_list[$key]['cat'],
                "cat_type" => $data_list[$key]['cat_type'],
                "subcat" => $data_list[$key]['subcat'],
            );
            $data_list[$key]['location'] = json_decode($item['location']);
            unset($data_list[$key]['id']);
            unset($data_list[$key]['admin_id']);
            unset($data_list[$key]['status']);
            unset($data_list[$key]['timestamp']);
        }
        $type = "addiopizzo";
        $detail_item = $this->story_detail_model->get(array("type" => $type));
        $detail_info = array();
        if (!empty($detail_item)) {

            $detail_description_info = $this->story_description_model->get(array('key' => $detail_item['description'], 'type' => $type . "_detail"));
            $detail_description_en = "";
            $detail_description_it = "";
            if (!empty($detail_description_info)) {
                $detail_description_en = $detail_description_info['des_en'];
                $detail_description_it = $detail_description_info['des_it'];
            }
            if ($detail_description_en == null) {
                $detail_description_en = "";
            }
            if ($detail_description_it == null) {
                $detail_description_it = "";
            }

            $detail_info['description'] = array(
                "en" => $detail_description_en,
                "it" => $detail_description_it,
            );

            $detail_content_info = $this->story_description_model->get(array('key' => $detail_item['bodyguard_title'], 'type' => $type . "_detail"));
            $detail_content_en = "";
            $detail_content_it = "";
            if (!empty($detail_content_info)) {
                $detail_content_en = $detail_content_info['des_en'];
                $detail_content_it = $detail_content_info['des_it'];
            }
            if ($detail_content_en == null) {
                $detail_content_en = "";
            }
            if ($detail_content_it == null) {
                $detail_content_it = "";
            }

            $detail_info['bodyguard_title'] = array(
                "en" => $detail_content_en,
                "it" => $detail_content_it,
            );

            $detail_info['name'] = empty($detail_item['name']) ? "" : $detail_item['name'];
            $detail_info['short_name'] = empty($detail_item['short_name']) ? "" : $detail_item['short_name'];
            $detail_info['profile_icon'] = empty($detail_item['profile_icon']) ? "" : $detail_item['profile_icon'];
            $detail_info['speaker_icon'] = empty($detail_item['speaker_icon']) ? "" : $detail_item['speaker_icon'];
            $detail_info['augmented_sound_url'] = empty($detail_item['augmented_sound_url']) ? "" : $detail_item['augmented_sound_url'];
            $detail_info['resources_base_url'] = $detail_item['resources_base_url'];
        }
        
        output_data(array("entry" => $data_list, "detail" => $detail_info));
    }
    public function get_configuration()
    {
        $data_list = $this->configuration_model->get_all(array('status' => 1, 'type' => 'configuration'));
        foreach ($data_list as $key => $item) {
            $data_list[$key]['opengl_renderer_low'] = json_decode($item['opengl_renderer_low']);
            $data_list[$key]['server_base_url'] = $item['server_base_url'];
            unset($data_list[$key]['id']);
            unset($data_list[$key]['admin_id']);
            unset($data_list[$key]['status']);
            unset($data_list[$key]['type']);
            unset($data_list[$key]['timestamp']);
        }
        output_data($data_list[0]);
    }
    public function get_configuration_produzione()
    {
        $data_list = $this->configuration_model->get_all(array('status' => 1, 'type' => 'configuration_produzione'));
        foreach ($data_list as $key => $item) {
            $data_list[$key]['opengl_renderer_low'] = json_decode($item['opengl_renderer_low']);
            $data_list[$key]['server_base_url'] = $item['server_base_url'];
            unset($data_list[$key]['id']);
            unset($data_list[$key]['admin_id']);
            unset($data_list[$key]['status']);
            unset($data_list[$key]['type']);
            unset($data_list[$key]['timestamp']);
        }
        output_data($data_list[0]);
    }
    public function parse_francese()
    {
        $path = APPPATH . 'json/script_francese.json';
        $files = file_get_contents($path);
        $data_list = json_decode($files, true);

        $update_data = array();
        $update_data['cube_rotations'] = json_encode($data_list['cube_rotations']);
        $update_data['cube_textures'] = json_encode($data_list['cube_textures']);
        $update_data['cube_textures_low'] = json_encode($data_list['cube_textures_low']);
        $update_data['steps'] = json_encode($data_list['steps']);
        $update_data['supported_languages'] = json_encode($data_list['supported_languages']);
        $update_data['visual_dataset'] = $data_list['visual_dataset'];
        $update_data['visual_url'] = $data_list['visual_url'];

        $update_data['admin_id'] = 1;
        $update_data['timestamp'] = TIMESTAMP;

        $insert_id = $this->francese_model->insert($update_data);

        output_data(1);
    }
    public function parse_configuration()
    {
        $type = get_param_from_request('type');
        if (empty($type)) {
            output_error("type is required");
        }
        if ($type == "configuration") {
            $path = APPPATH . 'json/configuration.json';
        } else {
            $path = APPPATH . 'json/configuration_produzione.json';
        }

        $files = file_get_contents($path);
        $data_list = json_decode($files, true);

        $update_data = array();
        $update_data['opengl_renderer_low'] = json_encode($data_list['opengl_renderer_low']);
        $update_data['server_base_url'] = $data_list['server_base_url'];
        $update_data['type'] = $type;

        $update_data['admin_id'] = 1;
        $update_data['timestamp'] = TIMESTAMP;

        $insert_id = $this->configuration_model->insert($update_data);

        output_data(1);
    }
    public function parse_addiopizzo()
    {
        $path = APPPATH . 'json/addiopizzo.json';
        $files = file_get_contents($path);
        $data_list = json_decode($files, true);

        $update_data = array();
        $entry_list = json_encode($data_list['entry']);
        $update_data['entry'] = $entry_list;
        $update_data['info'] = json_encode($data_list['info']);
        $update_data['itemsPerPage'] = $data_list['itemsPerPage'];
        $update_data['startIndex'] = $data_list['startIndex'];
        $update_data['totalResults'] = $data_list['totalResults'];

        $update_data['admin_id'] = 1;
        $update_data['timestamp'] = TIMESTAMP;

        // $insert_id = $this->addiopizzo_model->insert($update_data);

        $english_des = $data_list['supported_languages']['en'];
        $italy_des = $data_list['supported_languages']['it'];

        $type = "addiopizzo";
        
        foreach ($data_list['entry'] as $key => $val) {
            $entry_item = array();
            $entry_item['name'] = $val['name'];
            $entry_item['description'] = $val['description'];
            $entry_item['cat'] = $val['extra']['cat'];
            $entry_item['cat_type'] = $val['extra']['cat_type'];
            $entry_item['subcat'] = $val['extra']['subcat'];
            $entry_item['location'] = json_encode($val['location']);
            $entry_item['phone'] = $val['contacts']['phone'];
            $entry_item['web'] = $val['contacts']['web'];
            $entry_item['timestamp'] = TIMESTAMP;
            $this->addiopizzo_model->insert($entry_item);
        }
        foreach ($english_des as $key => $val) {
            $update_data = array();
            $update_data['key'] = $key;
            $update_data['des_en'] = $val;
            $update_data['type'] = $type;

            $des_info = $this->story_description_model->get(array("key" => $key, "type" => $type));
            if (empty($des_info)) {
                $this->story_description_model->insert($update_data);
            } else {
                $this->story_description_model->update($update_data, array("key" => $key, "type" => $type));
            }
        }
        foreach ($italy_des as $key => $val) {
            $update_data = array();
            $update_data['key'] = $key;
            $update_data['des_it'] = $val;
            $update_data['type'] = $type;

            $des_info = $this->story_description_model->get(array("key" => $key, "type" => $type));
            if (empty($des_info)) {
                $this->story_description_model->insert($update_data);
            } else {
                $this->story_description_model->update($update_data, array("key" => $key, "type" => $type));
            }
        }

        output_data(1);
    }
    public function parse_json()
    {
        $type = get_param_from_request('type');
        if (empty($type)) {
            output_error("type is required");
        }
        $path = "";
        switch ($type) {
            case "story":
                $path = FCPATH . 'uploads\contents\v8\stories.json';
                break;
            case "isop":
                $path = FCPATH . 'uploads\contents\v8\isop.json';
                break;
            case "ipicciridi":
                $path = FCPATH . 'uploads\contents\v8\ipicciridi.json';
                break;
            case "ilegal":
                $path = FCPATH . 'uploads\contents\v8\ilegal.json';
                break;
            case "extra":
                $path = FCPATH . 'uploads\contents\v8\extra.json';
                break;
            case "canzoni":
                $path = FCPATH . 'uploads\contents\v8\canzoni.json';
                break;
        }
        if (empty($path)) {
            output_error("no json file");
        }

        $files = file_get_contents($path);
        $data_list = json_decode($files, true);
        $english_des = $data_list['supported_languages']['en'];
        $italy_des = $data_list['supported_languages']['it'];
        foreach ($english_des as $key => $val) {
            $update_data = array();
            $update_data['key'] = $key;
            $update_data['des_en'] = $val;
            $update_data['type'] = $type;

            $des_info = $this->story_description_model->get(array("key" => $key, "type" => $type));
            if (empty($des_info)) {
                $this->story_description_model->insert($update_data);
            } else {
                $this->story_description_model->update($update_data, array("key" => $key, "type" => $type));
            }
        }
        foreach ($italy_des as $key => $val) {
            $update_data = array();
            $update_data['key'] = $key;
            $update_data['des_it'] = $val;
            $update_data['type'] = $type;

            $des_info = $this->story_description_model->get(array("key" => $key, "type" => $type));
            if (empty($des_info)) {
                $this->story_description_model->insert($update_data);
            } else {
                $this->story_description_model->update($update_data, array("key" => $key, "type" => $type));
            }
        }

        $stories = $data_list['stories'];
        for ($i = 0; $i < sizeof($stories); $i++) {
            $update_data = array();
            $update_data['type'] = $type;
            $update_data['augmented_story'] = $stories[$i]['augmented_story'];

            $update_data['background'] = $stories[$i]['background'];
            $update_data['description'] = $stories[$i]['description'];
            $update_data['facebook_photoID'] = $stories[$i]['facebook_photoID'];
            $update_data['geofenceAlert'] = $stories[$i]['geofenceAlert'];
            $update_data['geofenceTitle'] = $stories[$i]['geofenceTitle'];
            $update_data['icon'] = $stories[$i]['icon'];
            $update_data['index'] = $stories[$i]['id'];
            $update_data['link'] = $stories[$i]['link'];
            $update_data['map_icon'] = $stories[$i]['map_icon'];
            $update_data['name'] = $stories[$i]['name'];
            $update_data['pinpoint_icon'] = $stories[$i]['pinpoint_icon'];
            $update_data['profile_icon'] = $stories[$i]['profile_icon'];
            $update_data['resources_base_url'] = $stories[$i]['resources_base_url'];
            $update_data['share_icon'] = $stories[$i]['share_icon'];
            $update_data['short_name'] = $stories[$i]['short_name'];
            $update_data['speakerDescription'] = $stories[$i]['speakerDescription'];
            $update_data['speaker_icon'] = $stories[$i]['speaker_icon'];
            $update_data['story_version'] = $stories[$i]['story_version'];
            $update_data['address'] = json_encode($stories[$i]['address']);
            if (isset($stories[$i]['bodyguard_team'])) {
                $update_data['bodyguard_team'] = json_encode($stories[$i]['bodyguard_team']);
            } else {
                $update_data['bodyguard_team'] = json_encode(array());
            }
            if (isset($stories[$i]['bodyguard_title'])) {
                $update_data['bodyguard_title'] = $stories[$i]['bodyguard_title'];
            } else {
                $update_data['bodyguard_title'] = "";
            }
            if (isset($stories[$i]['bundled_story'])) {
                $update_data['bundled_story'] = $stories[$i]['bundled_story'];
            } else {
                $update_data['bundled_story'] = "";
            }
            if (isset($stories[$i]['available_story'])) {
                $update_data['available_story'] = $stories[$i]['available_story'];
            } else {
                $update_data['available_story'] = "";
            }
            
            if (isset($stories[$i]['augmented_page'])) {
                $update_data['augmented_page'] = $stories[$i]['augmented_page'];
            } else {
                $update_data['augmented_page'] = "";
            }
            if (isset($stories[$i]['augmented_eye'])) {
                $update_data['augmented_eye'] = $stories[$i]['augmented_eye'];
            } else {
                $update_data['augmented_eye'] = "";
            }
            if (isset($stories[$i]['augmented_sound'])) {
                $update_data['augmented_sound'] = $stories[$i]['augmented_sound'];
            } else {
                $update_data['augmented_sound'] = "";
            }
            if (isset($stories[$i]['augmented_sound_url'])) {
                $update_data['augmented_sound_url'] = $stories[$i]['augmented_sound_url'];
            } else {
                $update_data['augmented_sound_url'] = "";
            }
            $update_data['admin_id'] = 1;
            $update_data['timestamp'] = TIMESTAMP;

            $story_id = $this->story_model->insert($update_data);

        }
        output_data(1);
    }
    public function parse_isop()
    {
        $path = APPPATH . 'json/isop.json';
        $files = file_get_contents($path);
        $data_list = json_decode($files, true);
        $english_des = $data_list['supported_languages']['en'];
        $italy_des = $data_list['supported_languages']['it'];

        foreach ($english_des as $key => $val) {
            $update_data = array();
            $update_data['key'] = $key;
            $update_data['des_en'] = $val;

            $des_info = $this->story_description_model->get(array("key" => $key));
            if (empty($des_info)) {
                $this->story_description_model->insert($update_data);
            } else {
                $this->story_description_model->update($update_data, array("key" => $key));
            }
        }
        foreach ($italy_des as $key => $val) {
            $update_data = array();
            $update_data['key'] = $key;
            $update_data['des_it'] = $val;

            $des_info = $this->story_description_model->get(array("key" => $key));
            if (empty($des_info)) {
                $this->isop_description_model->insert($update_data);
            } else {
                $this->isop_description_model->update($update_data, array("key" => $key));
            }
        }

        $stories = $data_list['stories'];
        for ($i = 0; $i < sizeof($stories); $i++) {
            $update_data = array();
            $update_data['augmented_story'] = $stories[$i]['augmented_story'];
            $update_data['available_story'] = $stories[$i]['available_story'];
            $update_data['background'] = $stories[$i]['background'];
            $update_data['description'] = $stories[$i]['description'];
            $update_data['facebook_photoID'] = $stories[$i]['facebook_photoID'];
            $update_data['geofenceAlert'] = $stories[$i]['geofenceAlert'];
            $update_data['geofenceTitle'] = $stories[$i]['geofenceTitle'];
            $update_data['icon'] = $stories[$i]['icon'];
            $update_data['index'] = $stories[$i]['id'];
            $update_data['link'] = $stories[$i]['link'];
            $update_data['map_icon'] = $stories[$i]['map_icon'];
            $update_data['name'] = $stories[$i]['name'];
            $update_data['pinpoint_icon'] = $stories[$i]['pinpoint_icon'];
            $update_data['profile_icon'] = $stories[$i]['profile_icon'];
            $update_data['resources_base_url'] = $stories[$i]['resources_base_url'];
            $update_data['share_icon'] = $stories[$i]['share_icon'];
            $update_data['short_name'] = $stories[$i]['short_name'];
            $update_data['speakerDescription'] = $stories[$i]['speakerDescription'];
            $update_data['speaker_icon'] = $stories[$i]['speaker_icon'];
            $update_data['story_version'] = $stories[$i]['story_version'];
            $update_data['address'] = json_encode($stories[$i]['address']);
            if (isset($stories[$i]['bodyguard_team'])) {
                $update_data['bodyguard_team'] = json_encode($stories[$i]['bodyguard_team']);
            } else {
                $update_data['bodyguard_team'] = json_encode(array());
            }
            if (isset($stories[$i]['bodyguard_title'])) {
                $update_data['bodyguard_title'] = $stories[$i]['bodyguard_title'];
            } else {
                $update_data['bodyguard_title'] = "";
            }
            if (isset($stories[$i]['bundled_story'])) {
                $update_data['bundled_story'] = $stories[$i]['bundled_story'];
            } else {
                $update_data['bundled_story'] = "";
            }
            $update_data['admin_id'] = 1;
            $update_data['timestamp'] = TIMESTAMP;

            $story_id = $this->isop_model->insert($update_data);

        }
        output_data(1);
    }
    public function get_project_detail() {
        $type = "project";
        $detail_item = $this->project_model->get(array("id" => 1));
        $detail_info = array();
        if (!empty($detail_item)) {

            $detail_title_info = $this->story_description_model->get(array('key' => "title", 'type' => $type));
            $detail_title_en = "";
            $detail_title_it = "";
            if (!empty($detail_title_info)) {
                $detail_title_en = $detail_title_info['des_en'];
                $detail_title_it = $detail_title_info['des_it'];
            }
            if ($detail_title_en == null) {
                $detail_title_en = "";
            }
            if ($detail_title_it == null) {
                $detail_title_it = "";
            }

            $detail_info['title'] = array(
                "en" => $detail_title_en,
                "it" => $detail_title_it,
            );

            $detail_description_info = $this->story_description_model->get(array('key' => "description", 'type' => $type));
            $detail_description_en = "";
            $detail_description_it = "";
            if (!empty($detail_description_info)) {
                $detail_description_en = $detail_description_info['des_en'];
                $detail_description_it = $detail_description_info['des_it'];
            }
            if ($detail_description_en == null) {
                $detail_description_en = "";
            }
            if ($detail_description_it == null) {
                $detail_description_it = "";
            }

            $detail_info['description'] = array(
                "en" => $detail_description_en,
                "it" => $detail_description_it,
            );

            $detail_content_info = $this->story_description_model->get(array('key' => "content", 'type' => $type));
            $detail_content_en = "";
            $detail_content_it = "";
            if (!empty($detail_content_info)) {
                $detail_content_en = $detail_content_info['des_en'];
                $detail_content_it = $detail_content_info['des_it'];
            }
            if ($detail_content_en == null) {
                $detail_content_en = "";
            }
            if ($detail_content_it == null) {
                $detail_content_it = "";
            }

            $detail_info['content'] = array(
                "en" => $detail_content_en,
                "it" => $detail_content_it,
            );

            $detail_credit1_info = $this->story_description_model->get(array('key' => "credit1", 'type' => $type));
            $detail_credit1_en = "";
            $detail_credit1_it = "";
            if (!empty($detail_credit1_info)) {
                $detail_credit1_en = $detail_credit1_info['des_en'];
                $detail_credit1_it = $detail_credit1_info['des_it'];
            }
            if ($detail_credit1_en == null) {
                $detail_credit1_en = "";
            }
            if ($detail_credit1_it == null) {
                $detail_credit1_it = "";
            }

            $detail_info['credit1'] = array(
                "en" => $detail_credit1_en,
                "it" => $detail_credit1_it,
            );

            $detail_credit2_info = $this->story_description_model->get(array('key' => "credit2", 'type' => $type));
            $detail_credit2_en = "";
            $detail_credit2_it = "";
            if (!empty($detail_credit2_info)) {
                $detail_credit2_en = $detail_credit2_info['des_en'];
                $detail_credit2_it = $detail_credit2_info['des_it'];
            }
            if ($detail_credit2_en == null) {
                $detail_credit2_en = "";
            }
            if ($detail_credit2_it == null) {
                $detail_credit2_it = "";
            }

            $detail_info['credit2'] = array(
                "en" => $detail_credit2_en,
                "it" => $detail_credit2_it,
            );

            $detail_credit3_info = $this->story_description_model->get(array('key' => "credit3", 'type' => $type));
            $detail_credit3_en = "";
            $detail_credit3_it = "";
            if (!empty($detail_credit3_info)) {
                $detail_credit3_en = $detail_credit3_info['des_en'];
                $detail_credit3_it = $detail_credit3_info['des_it'];
            }
            if ($detail_credit3_en == null) {
                $detail_credit3_en = "";
            }
            if ($detail_credit3_it == null) {
                $detail_credit3_it = "";
            }

            $detail_info['credit3'] = array(
                "en" => $detail_credit3_en,
                "it" => $detail_credit3_it,
            );

            $detail_info['profile_icon'] = empty($detail_item['profile_icon']) ? "" : $detail_item['profile_icon'];
            $detail_info['speaker_icon1'] = empty($detail_item['speaker_icon1']) ? "" : $detail_item['speaker_icon1'];
            $detail_info['speaker_icon2'] = empty($detail_item['speaker_icon2']) ? "" : $detail_item['speaker_icon2'];
            $detail_info['speaker_icon3'] = empty($detail_item['speaker_icon3']) ? "" : $detail_item['speaker_icon3'];
            $detail_info['speaker_icon4'] = empty($detail_item['speaker_icon4']) ? "" : $detail_item['speaker_icon4'];
            $detail_info['speaker_icon5'] = empty($detail_item['speaker_icon5']) ? "" : $detail_item['speaker_icon5'];
            $detail_info['media'] = empty($detail_item['media']) ? "" : $detail_item['media'];
            $detail_info['resources_base_url'] = $detail_item['resources_base_url'];
        }
        
        output_data(array("detail" => $detail_info));
    }
    public function test()
    {
        output_data(1);
    }
}
